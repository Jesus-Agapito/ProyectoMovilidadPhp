<?php
include "Empleado.php";
include "Gerente.php";

$empleado1 = new Empleado("Aga", "Laza", 25, 160, 25);
$empleado1->anyadirTelefono(611223344);
$empleado1->anyadirTelefono(915554433);

$gerente1 = new Gerente("María", "Pérez", 40, 3000);
$gerente1->anyadirTelefono(699887766);
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejercicio 312 - Trabajador</title>
</head>
<body>
<h1>Prueba del Ejercicio 312</h1>

<h2>Datos del Empleado:</h2>
<?php
echo "<p>" . $empleado1 . "</p>";
echo "<p><strong>Impuestos:</strong> " . ($empleado1->debePagarImpuestos() ? "Tiene que pagar impuestos" : "No tiene que pagar impuestos") . "</p>";
echo Empleado::toHtml($empleado1);
?>

<hr>

<h2>Datos del Gerente:</h2>
<?php
echo "<p>" . $gerente1 . "</p>";
echo "<p><strong>Impuestos:</strong> " . ($gerente1->debePagarImpuestos() ? "Tiene que pagar impuestos" : "No tiene que pagar impuestos") . "</p>";
echo Gerente::toHtml($gerente1);
?>
</body>
</html>